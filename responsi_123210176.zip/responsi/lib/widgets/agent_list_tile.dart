import 'package:flutter/material.dart';
import '../models/agent.dart';

class AgentListTile extends StatelessWidget {
  final Agent agent;
  final VoidCallback onTap;

  AgentListTile({required this.agent, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.network(agent.displayIcon),
      title: Text(agent.displayName),
      subtitle: Text(agent.description),
      onTap: onTap,
    );
  }
}
