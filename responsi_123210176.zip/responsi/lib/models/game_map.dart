class GameMap {
  final String uuid;
  final String displayName;
  final String splash;
  final String displayIcon;
  final String coordinates;

  GameMap({
    required this.uuid,
    required this.displayName,
    required this.splash,
    required this.displayIcon,
    required this.coordinates,
  });

  factory GameMap.fromJson(Map<String, dynamic> json) {
    return GameMap(
      uuid: json['uuid'] ?? '',
      displayName: json['displayName'] ?? '',
      splash: json['splash'] ?? '',
      displayIcon: json['displayIcon'] ?? '',
      coordinates: json['coordinates'] ?? '',
    );
  }
}
