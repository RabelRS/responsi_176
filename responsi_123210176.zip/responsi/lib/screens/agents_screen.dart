import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/agent.dart';
import '../widgets/agent_list_tile.dart';
import 'agent_detail_screen.dart';

class AgentsScreen extends StatelessWidget {
  final ApiService apiService = ApiService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agents'),
      ),
      body: FutureBuilder<List<Agent>>(
        future: apiService.fetchAgents(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error: ${snapshot.error}',
                style: TextStyle(color: Colors.red), // Memberikan warna merah pada teks error
              ),
            );
          } else if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final agent = snapshot.data![index];
                return AgentListTile(
                  agent: agent,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AgentDetailScreen(agent: agent),
                      ),
                    );
                  },
                );
              },
            );
          } else {
            return Center(
              child: Text('No data available'),
            );
          }
        },
      ),
    );
  }
}
