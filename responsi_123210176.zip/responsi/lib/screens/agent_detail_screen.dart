import 'package:flutter/material.dart';
import '../models/agent.dart';

class AgentDetailScreen extends StatelessWidget {
  final Agent agent;

  AgentDetailScreen({required this.agent});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(agent.displayName ?? 'Unknown'), // Penanganan nilai null
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (agent.fullPortrait != null) Image.network(agent.fullPortrait),
            SizedBox(height: 16.0),
            Text(
              agent.displayName ?? 'Unknown', // Penanganan nilai null
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text(
              'Description: ${agent.description ?? 'No description available'}', // Penanganan nilai null
              style: TextStyle(fontSize: 16),
            ),
            // Tambahkan penanganan untuk properti lain yang mungkin bernilai null
          ],
        ),
      ),
    );
  }
}
